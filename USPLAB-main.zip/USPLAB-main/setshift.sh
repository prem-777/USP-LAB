#!/bin/sh

set `date`

for i in $*
do 
	echo $1
	shift
	
done
