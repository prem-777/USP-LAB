#!/bin/sh

echo "Enter DIR name"
read name
cd $name
ls -l
