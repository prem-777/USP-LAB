#!/bin/sh

d=`echo "scale=2; 5 / 9"|bc`
echo $d
