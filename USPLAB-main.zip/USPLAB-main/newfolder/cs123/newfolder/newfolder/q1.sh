#!/bin/sh
ls
echo "Enter File name"
read name
wc $name
